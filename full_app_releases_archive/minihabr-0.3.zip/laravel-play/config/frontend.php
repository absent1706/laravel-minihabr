<?php

return [
   'articles_per_page' => 5,
   'comments_per_page' => 10,
];