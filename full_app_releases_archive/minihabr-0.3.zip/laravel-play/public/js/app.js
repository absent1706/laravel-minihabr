$(function() {
  $('.alert.alert-info, .alert.alert-success').delay(5000).slideUp(500);
});