@extends('layouts.default')

@section('content')
    <h1>Contact</h1>
    Lorem ipsum
@stop