-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.0.17-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             8.3.0.4796
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for corpblog
DROP DATABASE IF EXISTS `corpblog`;
CREATE DATABASE IF NOT EXISTS `corpblog` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;
USE `corpblog`;


-- Dumping structure for table corpblog.articles
DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `articles_category_id_foreign` (`category_id`),
  CONSTRAINT `articles_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.articles: ~10 rows (approximately)
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` (`id`, `user_id`, `title`, `body`, `created_at`, `updated_at`, `category_id`) VALUES
	(1, 1, 'tttt', 'bbbbbbbbbbbbbbbbbbbbbbbbb', '2015-11-02 18:54:08', '2015-11-02 18:54:08', 1),
	(4, 1, '4tttt', '4bbbbbbbbbbbbbbbbbbbbbbbbb', '2015-11-02 18:54:07', '2015-11-02 18:54:08', 1),
	(12, 1, 'cfdcxvxvvxzv', 'dfdfds', '2015-11-09 13:54:58', '2015-11-09 13:54:58', 1),
	(18, 1, 'cxzc edited by admin', 'xzczxczxczxc', '2015-11-09 14:02:33', '2015-11-21 12:23:46', 2),
	(21, 1, 'dfdsfds', 'fdsfdsfdsfdsfsdfdsf', '2015-11-09 14:00:43', '2015-11-09 14:00:43', 3),
	(22, 2, 'sfdsf', 'dsfdsfsdfsdfdfdsfdsfsdfdsfdsfdsf', '2015-11-15 18:25:27', '2015-11-15 19:20:55', 3),
	(23, 2, 'gdfgd', 'fgdfg', '2015-11-15 18:29:16', '2015-11-15 18:29:16', 3),
	(25, 2, 'sdf', 'sdfdsf', '2015-11-15 18:33:23', '2015-11-15 18:33:23', 3),
	(27, 2, 'fgvdfg', 'dfgdfgdf', '2015-11-15 18:35:39', '2015-11-15 18:35:39', 3),
	(34, 2, 'nnnnnnnnnnnnn', 'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnnannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\r\nn\r\nnnnnnnnnnnnnnna', '2015-11-21 12:59:37', '2015-11-21 12:59:37', 3);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;


-- Dumping structure for table corpblog.categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.categories: ~4 rows (approximately)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`, `order`) VALUES
	(1, 'Category 1', '0000-00-00 00:00:00', '2015-11-22 14:54:59', 10),
	(2, 'cat2', '0000-00-00 00:00:00', '2015-11-22 14:55:07', 20),
	(3, 'category 3', '0000-00-00 00:00:00', '2015-11-22 14:55:15', 30);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


-- Dumping structure for table corpblog.comments
DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `comments_article_id_foreign` (`article_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  CONSTRAINT `comments_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.comments: ~17 rows (approximately)
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` (`id`, `article_id`, `user_id`, `body`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, 'comment 1', '2014-11-03 19:21:34', '0000-00-00 00:00:00'),
	(15, 18, 2, 'dsfdsf', '2015-11-14 21:44:01', '2015-11-14 21:44:01'),
	(18, 21, 1, 'fds gsdf gdfsg fdsg df', '2015-11-15 19:31:26', '2015-11-15 19:31:26'),
	(20, 21, 6, 'fds gsdf gdfsg fdsg df', '2015-11-15 19:31:26', '2015-11-15 19:31:26'),
	(21, 21, 2, 'fds gsdf gdfsg fdsg df', '2015-11-15 19:31:26', '2015-11-15 19:31:26'),
	(22, 21, 2, 'fgfd sg dfgdfg d', '2015-11-15 19:33:05', '2015-11-15 19:33:05'),
	(23, 21, 2, 'fg fgsdfg', '2015-11-15 19:34:40', '2015-11-15 19:34:40'),
	(73, 27, 2, 'ds fda ', '2015-11-21 09:47:14', '2015-11-21 09:47:14'),
	(74, 27, 2, 'ds fda ', '2015-11-21 09:47:16', '2015-11-21 09:47:16'),
	(75, 27, 2, 'ds fda ', '2015-11-21 09:47:17', '2015-11-21 09:47:17'),
	(76, 27, 2, 'sd f asdf s', '2015-11-21 09:47:29', '2015-11-21 09:47:29'),
	(77, 27, 2, 'r  dfsg dfg f', '2015-11-21 09:47:47', '2015-11-21 09:47:47'),
	(88, 34, 2, '1', '2015-11-21 13:01:57', '2015-11-21 13:01:57'),
	(89, 34, 8, '2', '2015-11-21 13:02:00', '2015-11-21 13:02:00'),
	(90, 34, 2, '3', '2015-11-21 13:02:04', '2015-11-21 13:02:04'),
	(91, 34, 8, '4', '2015-11-21 13:02:08', '2015-11-21 13:02:08'),
	(92, 34, 2, '5', '2015-11-21 13:02:11', '2015-11-21 13:02:11');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;


-- Dumping structure for table corpblog.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.migrations: ~13 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`migration`, `batch`) VALUES
	('2014_10_12_000000_create_users_table', 1),
	('2014_10_12_100000_create_password_resets_table', 1),
	('2015_11_01_162625_create_articles_table', 1),
	('2015_11_03_204139_create_comments_table', 1),
	('2015_11_03_213543_create_categories_table', 1),
	('2015_11_03_213930_add_category_id_to_articles_table', 1),
	('2014_10_12_000000_create_users_table', 1),
	('2014_10_12_100000_create_password_resets_table', 1),
	('2015_11_01_162625_create_articles_table', 1),
	('2015_11_03_204139_create_comments_table', 2),
	('2015_11_03_213543_create_categories_table', 3),
	('2015_11_21_121353_add_is_admin_flag_to_users_table', 4),
	('2015_11_22_140241_add_order_field_to_categories_table', 5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;


-- Dumping structure for table corpblog.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;


-- Dumping structure for table corpblog.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.users: ~7 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `is_admin`) VALUES
	(1, 'john', 'ololo@ololo.com', '$2y$10$ihjBvJAEF/6DuOJejMZHV.rpieG7aU47bDbo0ZsIqeyfHaGLRoBJa', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
	(2, 'Alexxxxx', 'litvinenko1706@gmail.com', '$2y$10$SNzsUCkqUC90I/jhDp4S7.8lcuTWmNjhLltFQy/wBleKJo03P4UUe', '2MSHvzKbb2zATkKOOSBXaPgCyrmXbo5soyS1PiwGw6HKKut1cBecjQtQDabq', '2015-11-02 19:21:34', '2015-11-21 12:58:42', 0),
	(3, 'third name', 'third@mail.com', '$2y$10$x2zH8pChABVpwM5k1BtKcObfR6remVUjwqACrYvhR4C/3QI5ZZYrS', NULL, '2015-11-03 19:21:34', '2015-11-02 19:21:34', 0),
	(4, 'second', 's@s.com', '$2y$10$QtQ2qB4tprnnbVQcF6L6seRaBdLQpLWmXZSe44sIqxK/BJHkwiVKG', 'i6HIQDzbg5rSWdlHRgBU8EEdbFvANLB7DDIICOlZvD9hkS8oI5KkzCnYUCvT', '2015-11-09 08:33:35', '2015-11-09 08:49:18', 0),
	(5, 'sadasd', 'admin@f.comf', '$2y$10$8QuPXvNkPHCxGHT.C1SWX.1iP2T8L6vq/ANpcawNyhT6QkDxwnV66', 'QUJlMAfdM0H2zkiSrokEt9DaXIUuT57x4YpgWBqpgui7SCIDrjt2IzNk96CR', '2015-11-09 09:31:45', '2015-11-09 09:53:02', 0),
	(6, 'sadasd', 'admin@sd.com', '$2y$10$o4z5I5mQ1Jq0gYdaT7tDYumYLWCQSvvCAqrkOgKjIoMETnwE80J6a', 'J0Xefnd2UhxxT9bQI0m0Bqkhxxe7o1ap7zBwhAIlRv64JgQVRpP1Ni9EFovh', '2015-11-09 12:53:03', '2015-11-09 13:03:04', 0),
	(8, 'admin', 'admin@admin.com', '$2y$10$WMnxWaqsyT3w3FgaVl.tjeMr99B9AJhUkWz1k7TRgDK6DNKu2iyqK', 'rBJ8jRNx4aiykmfzGXaWjTAi1Z7r07EEQbNesx6cgEQRpri6t5qCghzB26te', '2015-11-21 12:17:50', '2015-11-22 16:30:36', 1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
