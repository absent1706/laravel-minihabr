@extends('layouts.default')

@section('content')

<h1 class="text-center">Sorry, page you requested does not exist</h1>

@stop

